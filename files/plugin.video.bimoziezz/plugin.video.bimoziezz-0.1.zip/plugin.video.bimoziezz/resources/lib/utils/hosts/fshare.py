# -*- coding: utf-8 -*-
import urllib, pickle, time, json, re
import utils.xbmc_helper as helper
from utils.mozie_request import Request
from bs4 import BeautifulSoup
import requests
import xbmc

HEADERS = {
    'Content-type': 'application/json', 
    'Accept': 'text/plain',
    'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 6.0.1; FPT Play Box Build/Normal-6.7.106-20190111)'
}

class FShareVN:
    def __init__(self, url, username="", password=""):
        self.token = None
        self.session_id = None
        self.url = url
        self.username = username
        self.password = password
        self.request = Request(session=True)

    @staticmethod
    def get_info(url=None, content=None):
        if url:
            content = Request().get(url)

        name = False
        size = '0'
        soup = BeautifulSoup(content, "html.parser")
        title = soup.select_one('title').text.encode('utf-8')

        if 'Not Found' in title or '503' in title:
            raise Exception('Fshare', 'link die')

        info = soup.select_one('div.info')
        if info:
            name = info.select_one('div.name').get('title').encode('utf-8')

            size = info.select_one('div.size').get_text().strip() \
                .replace(" ", "") \
                .replace("\n", "") \
                .replace("save", "").encode('utf-8')

        return name, size

    def login(self, token=""):
        try:
            self.session_id = None
            self.token = None
            url = 'https://api2.fshare.vn/api/user/login/'
            r = requests.post(url, json={
                'user_email': self.username,
                'password': self.password,
                'app_key': 'tVDNf8QcQ5Sfasmm5ennLIjF5D11k21xCruVaAeJ'
            }, headers = HEADERS)

            # r = json.loads(r)
            r = r.json()

            self.session_id = r['session_id']
            self.token = r['token']
            
            return True
        except:
            raise Exception('Fshare', 'Can not login')
            return False


    def get_link(self):
        if '/folder/' in self.url:
            code = self.handleFolder(self.url)
            if not code:
                return None
            else:
                self.url = "https://www.fshare.vn/file/%s" % code

        self.url = self.url.split("?")[0]
        
        self.login()

        headers = HEADERS.copy()
        headers['Cookie'] = 'session_id=%s' % self.session_id

        r = requests.post('https://api2.fshare.vn/api/Session/download', data=json.dumps({
            'token': self.token,
            'url': self.url
        }), headers = headers)

        item = r.json()

        if int(self.request.head(item.get('location')).headers['Content-Length']):
            # self.logout()
            # helper.sleep(3000)
            return item.get('location')
        return

    def logout(self):
        self.request.get('https://api2.fshare.vn/api/user/logout')

    @staticmethod
    def is_folder(url):
        return '/folder/' in url

    def handleFolder(self, url=None, code=None):
        if not code:
            code = re.search(r'/folder/([^\?]+)', url).group(1)

        r = self.request.get('https://www.fshare.vn/api/v3/files/folder?linkcode=%s&sort=type,name' % code)
        r = json.loads(r)

        listitems = []
        if 'items' in r and len(r['items']) > 0:
            listitems = ["[%s] %s" % (i['type'] == 1 and helper.humanbytes(i["size"]) or 'Folder', i["name"]) for i in
                         r['items']]
        else:
            helper.message("Fshare link folder die")
            return

        index = helper.create_select_dialog(listitems)
        if index == -1: return None
        if r['items'][index]['type'] == 1:
            return r['items'][index]['linkcode']
        else:
            return self.handleFolder(code=r['items'][index]['linkcode'])
