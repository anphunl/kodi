#!/usr/bin/env python
# coding=utf-8

from utils.mozie_request import Request
from thuvienhd.parser.category import Parser as Category
from thuvienhd.parser.channel import Parser as Channel
from thuvienhd.parser.movie import Parser as Movie
import urllib
import xbmc

# https://thuvienhd.com/?feed=rss&exclude_cats=250004&category=80&posts_per_page=30&page=2
# https://thuvienhd.com/?feed=rss&exclude_cats=250004&posts_per_page=30&page=1&search=finding%20nemo
# https://thuvienhd.com/?feed=rss&id=153945
# cat = -1: top

user_agent = (
    "Mozilla/5.0 (X11; Linux x86_64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/59.0.3071.115 Safari/537.36"
)

h = {
    'User-Agent': user_agent,
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    # 'Host': 'http://www.phimmoizz.net',
    # 'Referer': 'http://www.phimmoizz.net/vn.php'
}

class Thuvienhd:
    domain = "https://thuvienhd.com"

    def __init__(self):
        self.request = Request(h, session=True)

    def getCategory(self):
        return Category().get(), []

    def getChannel(self, channel, page=1):
        channel = channel.replace(self.domain, "")
        if page > 1:
            url = '%s/%s/page/%d' % (self.domain, channel, page)
        else:
            url = '%s/%s' % (self.domain, channel)
        response = self.request.get(url, headers=h)
        return Channel().get(response, page)

    def getMovie(self, id):
        xbmc.log('**** get movie %s' % id, 2)
        url = 'https://thuvienhd.com/?feed=rss&id=%s' % id
        response = self.request.get(url, headers=h)
        return Movie().get(response)


    def search(self, text):
        url = '%s/?feed=rss&exclude_cats=250004&posts_per_page=300&page=1&search=%s' % (self.domain, urllib.quote_plus(text))
        response = self.request.get(url, headers=h)
        return Channel().get_search(response, 1)

