#!/usr/bin/env python
# -*- coding: utf-8 -*-

class Parser:
    def get(self):
		cats = [
                # {
                # 'title': 'Chương trình xuân 2021',
                # 'link': 'https://thuvienhd.com/genre/chuong_trinh-xuan',
                # 'subcategory': []
                # },
                {
                'title': 'Mới nhất',
                'link': 'https://thuvienhd.com/recent',
                'subcategory': []
                },
                {
                'title': 'Hot',
                'link': 'https://thuvienhd.com/trending',
                'subcategory': []
                },
                {
                'title': 'Thuyết minh',
                'link': 'https://thuvienhd.com/genre/thuyet-minh-tieng-viet',
                'subcategory': []
                },
                {
                'title': 'Lồng tiếng',
                'link': 'https://thuvienhd.com/genre/long-tieng-tieng-viet',
                'subcategory': []
                },
                # {
                # 'title': 'Phim lẻ theo quốc gia',
                # 'link': 'https://thuvienhd.com/genre/phim-le',
                # 'subcategory': [
                #     {
                #     'link': 'https://thuvienhd.com/genre/korean',
                #     'title': 'Hàn Quốc'
                #     },
                #     {
                #     'link': 'https://thuvienhd.com/genre/india',
                #     'title': 'Ấn Độ'
                #     },
                #     {
                #     'link': 'https://thuvienhd.com/genre/hongkong',
                #     'title': 'Hongkong'
                #     },
                #     {
                #     'link': 'https://thuvienhd.com/genre/trung-quoc-series',
                #     'title': 'Trung Quốc'
                #     },
                #     ]
                # },
                {
                'title': 'Phim lẻ',
                'link': 'https://thuvienhd.com/genre/phim-le',
                'subcategory': [
                    {
                    'link': 'https://thuvienhd.com/genre/action',
                    'title': 'Hành Động'
                    },
                    {
                    'link': 'https://thuvienhd.com/genre/sci-fi',
                    'title': 'Viễn Tưởng'
                    },
                    {
                    'link': 'https://thuvienhd.com/genre/horror',
                    'title': 'Kinh Dị'
                    },
                    
                    {
                    'link': 'https://thuvienhd.com/genre/3d',
                    'title': '3D'
                    },
                    {
                    'link': 'https://thuvienhd.com/genre/4k',
                    'title': '4K'
                    },
                    
                    {
                    'link': 'https://thuvienhd.com/genre/comedy',
                    'title': 'Hài'
                    },
                    {
                    'link': 'https://thuvienhd.com/genre/western',
                    'title': 'Cao Bồi'
                    },
                    {
                    'link': 'https://thuvienhd.com/genre/war',
                    'title': 'Chiến Tranh'
                    },
                    {
                    'link': 'https://thuvienhd.com/genre/chinh-kich',
                    'title': 'Chính Kịch'
                    },
                    {
                    'link': 'https://thuvienhd.com/genre/co-trang-phim',
                    'title': 'Cổ Trang'
                    },
                    {
                    'link': 'https://thuvienhd.com/genre/gia-dinh',
                    'title': 'Gia Đình'
                    },
                    {
                    'link': 'https://thuvienhd.com/genre/giang-sinh',
                    'title': 'Giáng Sinh'
                    },
                    {
                    'link': 'https://thuvienhd.com/genre/crime',
                    'title': 'Hình Sự'
                    },
                    {
                    'link': 'https://thuvienhd.com/genre/animation',
                    'title': 'Phim Hoạt Hình'
                    },
                    
                    {
                    'link': 'https://thuvienhd.com/genre/mystery',
                    'title': 'Huyền Bí'
                    },
                    {
                    'link': 'https://thuvienhd.com/genre/romance',
                    'title': 'Lãng Mạn'
                    },
                    {
                    'link': 'https://thuvienhd.com/genre/history',
                    'title': 'Lịch Sử'
                    },
                    {
                    'link': 'https://thuvienhd.com/genre/nhac-kich',
                    'title': 'Nhạc Kịch'
                    },
                    {
                    'link': 'https://thuvienhd.com/genre/adventure',
                    'title': 'Phiêu Lưu'
                    },
                    {
                    'link': 'https://thuvienhd.com/genre/phim',
                    'title': 'Phim'
                    },
                    {
                    'link': 'https://thuvienhd.com/genre/documentary',
                    'title': 'Phim Tài Liệu'
                    },
                    {
                    'link': 'https://thuvienhd.com/genre/thriller',
                    'title': 'Rùng Rợn'
                    },
                    {
                    'link': 'https://thuvienhd.com/genre/drama',
                    'title': 'Tâm Lý'
                    },
                    {
                    'link': 'https://thuvienhd.com/genre/fantasy',
                    'title': 'Thần Thoại'
                    },
                    {
                    'link': 'https://thuvienhd.com/genre/the-thao',
                    'title': 'Thể Thao'
                    },
                    {
                    'link': 'https://thuvienhd.com/genre/family',
                    'title': 'Thiếu Nhi'
                    },
                    {
                    'link': 'https://thuvienhd.com/genre/tieu-su',
                    'title': 'Tiểu Sử'
                    },
                    {
                    'link': 'https://thuvienhd.com/genre/tinh-cam',
                    'title': 'Tình Cảm'
                    },
                    {
                    'link': 'https://thuvienhd.com/genre/trinh-tham',
                    'title': 'Trinh Thám'
                    },
                    
                    {
                    'link': 'https://thuvienhd.com/genre/vo-thuat-phim-2',
                    'title': 'Võ Thuật'
                    }
                ]
                },
                {
                'title': 'Phim bộ',
                'link': 'https://thuvienhd.com/genre/series',
                'subcategory': [
                    {
                    'link': 'https://thuvienhd.com/genre/korean-series',
                    'title': 'Phim Bộ Hàn'
                    },
                    {
                    'link': 'https://thuvienhd.com/genre/us-tv-series',
                    'title': 'Phim Bộ Mỹ'
                    },
                    {
                    'link': 'https://thuvienhd.com/genre/phim-bo-dai-loan',
                    'title': 'Phim Bộ Đài Loan'
                    },
                    {
                    'link': 'https://thuvienhd.com/genre/hongkong-series',
                    'title': 'Phim Bộ Hongkong'
                    },
                    {
                    'link': 'https://thuvienhd.com/genre/phim-bo-trung-quoc',
                    'title': 'Phim Bộ Trung Quốc'
                    },
                    {
                    'link': 'https://thuvienhd.com/genre/phim-bo-nhat-ban',
                    'title': 'Phim Bộ Nhật Bản'
                    },
                    {
                    'link': 'https://thuvienhd.com/genre/phim-bo-an-do',
                    'title': 'Phim Bộ Ấn Độ'
                    },
                    {
                    'link': 'https://thuvienhd.com/genre/phim-bo-nhat-ban',
                    'title': 'Phim Bộ Nhật Bản'
                    },
                    {
                    'link': 'https://thuvienhd.com/genre/phim-bo-thai-lan',
                    'title': 'Phim Bộ Thái Lan'
                    }
                ]
                }
            ]

		return cats