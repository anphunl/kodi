#!/usr/bin/env python
# -*- coding: utf-8 -*-
from bs4 import BeautifulSoup
import re
import xbmc
import feedparser

class Parser:
	def get_search(self, response, page):
		channel = {
			'page': page,
			'page_patten': None,
			'movies': []
		}

		d = feedparser.parse(response)

		for entry in d.entries:
			title = entry.title
			# xbmc.log('**#### %s' % entry.enclosure, 2)
			try:
				thumb = entry.links[-1].href
			except:
				thumb = ''
			channel['movies'].append({
					'id': re.search('p=(\d+)', entry.id.strip()).group(1),
					'label': title,
					'title': title,
					'realtitle': title,
					'thumb': thumb,
					'type': '',
				})

		return channel

	def get(self, response, page):

		channel = {
			'page': page,
			'page_patten': None,
			'movies': []
		}

		soup = BeautifulSoup(response, "html.parser")
		# get total page
		pages = soup.select('div.pagination > span')
		# xbmc.log("*********************** Get pages ",2)

		if len(pages) > 0:
			total_pages = int(re.search('Page \d+ of (\d+)', pages[0].text.strip()).group(1))
			channel['page'] = total_pages

		for movie in soup.select('article.item'):
			movie_id = re.search('post-(\d+)', movie.get('id').strip()).group(1)
			poster_item = movie.select_one('div.poster > img')

			thumb = poster_item.get('src').strip()
			title = poster_item.get('alt').strip().encode("utf-8")
			# xbmc.log("*********************** %s" % title,2)

			channel['movies'].append({
				'id': movie_id,
				'label': title,
				'title': title,
				'realtitle': title,
				'thumb': thumb,
				'type': '',
			})

		return channel

    
