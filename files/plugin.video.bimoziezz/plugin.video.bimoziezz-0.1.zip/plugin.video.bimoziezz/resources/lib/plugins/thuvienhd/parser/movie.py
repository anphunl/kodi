# -*- coding: utf-8 -*-
from urllib import unquote
from utils.mozie_request import Request, AsyncRequest
import utils.xbmc_helper as helper
from utils.hosts.fshare import FShareVN
import re
import json
import feedparser
import xbmc


def from_char_code(*args):
    return ''.join(map(chr, args))


class Parser:
    def get(self, response, skipEps=False):
		movie = {
			'group': {},
			'episode': [],
			'links': [],
		}

		d = feedparser.parse(response)

		for entry in d.entries:
			for link in entry.links:
				if 'title' in link:
					is_folder = FShareVN.is_folder(link.href)
					if is_folder:
						title = '[Folder] %s' % link.title
					else:
						title = link.title
					movie['links'].append({
							'link': link.href,
							'title': title,
							'type': 'Unknown',
							'resolve': False,
							'isFolder': is_folder,
							'originUrl': ''
						})
		movie['links'] = movie['links'][:len(movie['links']) // 2]
		return movie

    


